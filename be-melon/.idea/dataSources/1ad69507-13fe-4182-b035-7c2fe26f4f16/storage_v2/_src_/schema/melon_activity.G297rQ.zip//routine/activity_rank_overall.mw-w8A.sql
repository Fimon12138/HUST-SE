create
    definer = root@localhost function activity_rank_overall(cur_timestamp timestamp, cur_point varchar(12),
                                                            target_timestamp timestamp,
                                                            target_point varchar(12)) returns float
begin
    declare score float;
    set score = 0.4 * activity_rank_time(cur_timestamp, target_timestamp) +
                      0.6 * activity_rank_distance(cur_point, target_point);
    return score;
end;

