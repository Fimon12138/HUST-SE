create
    definer = root@localhost function activity_rank_distance(cur_point varchar(12), target_point varchar(12)) returns tinyint
begin
    declare distance_point int;
    if (left(cur_point, 6) <=> left(target_point, 6)) then
        set distance_point = 10;
    elseif (left(cur_point, 5) <=> left(target_point, 5)) then
        set distance_point = 5;
    elseif (left(cur_point, 4) <=> left(target_point, 4)) then
        set distance_point = 2;
    else
        set distance_point = 0;
    end if;
    return distance_point;
end;

