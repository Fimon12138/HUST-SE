create
    definer = root@localhost function activity_rank_time(cur_time timestamp, target_time timestamp) returns int
begin
    declare time_diff, time_point int;
    set time_diff = timestampdiff(hour, cur_time, target_time);
    if (time_diff <= 2) then
        set time_point = 10;
    elseif (time_diff <= 12) then
        set time_point = 5;
    elseif (time_diff <= 24) then
        set time_point = 2;
    else
        set time_point = 0;
    end if;
    return time_point;
end;

